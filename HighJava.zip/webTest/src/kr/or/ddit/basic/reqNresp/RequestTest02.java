package kr.or.ddit.basic.reqNresp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RequestTest02.do")
public class RequestTest02 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		String front = request.getParameter("front");
		String cal = request.getParameter("cal");
		String back = request.getParameter("back");
		
		PrintWriter out = response.getWriter();
		
		response.setContentType("text/html; charset=utf-8");
		out.println("<html>");
		double res=0.0;
		double num1 = Double.parseDouble(front);
		double num2 = Double.parseDouble(back);
		boolean calcOk= true;
		switch(cal) {
		case "+" : res = num1 + num2; break;
		case "-" : res = num1 - num2; break;
		case "*" : res = num1 * num2; break;
		case "/" : res = num1 / num2; break;
		}
		/*
		 * if(cal.equals("+")) res = num1 + num2; 
		 * if(cal.equals("-")) res = num1 - num2;
		 * if(cal.equals("*")) res = num1 * num2; 
		 * if(cal.equals("/")) res = num1 / num2;
		 */
		out.println("<head><meta charset='utf-8'>"
				+ "<title>계산 결과</title></head>");
		out.println("<body>");
		out.println("<h2>계산 결과</h2>");
		out.println("<hr>");
		out.println(front + cal + back + "=" + res);
		/* out.println("</body></html>"); */
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
