package kr.or.ddit.basic.cookie;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cookieCountServlet.do")
public class CookieCountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		Cookie[] cookieArr = request.getCookies();
	
		Cookie ountCookie = new Cookie("count","0");
		
			
		//Integer.parseInt(countCookie.getValue());
		out.println("<html>");
		out.println("<head><meta charset='utf-8'>"
				+ "<title>Cookie 저장 연습2</title></head>" );
		out.println("<body>");
		out.println("<h3>어서오세요. 당신은" + "번째 방문입니다.</h3><br><br>");
		out.println("<a href='"+ request.getContextPath() + "/cookieCountServlet.do'>카운트 증가하기</a>");
		if(countCookie==null) c
		
		response.addCookie(countCookie);
		
		out.println("<a href='"+ request.getContextPath() +
				"/basic/cookie/cookieTest02.jsp'>시작 문서로 이동하기</a>");
		out.println("</body></html>");
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
